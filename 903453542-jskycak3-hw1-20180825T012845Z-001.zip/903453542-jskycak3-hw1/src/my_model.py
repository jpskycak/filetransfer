import utils
#Note: You can reuse code that you wrote in etl.py and models.py and cross.py over here. It might help.
# PLEASE USE THE GIVEN FUNCTION NAME, DO NOT CHANGE IT

'''
You may generate your own features over here.
Note that for the test data, all events are already filtered such that they fall in the observation window of their respective patients. Thus, if you were to generate features similar to those you constructed in code/etl.py for the test data, all you have to do is aggregate events for each patient.
IMPORTANT: Store your test data features in a file called "test_features.txt" where each line has the
patient_id followed by a space and the corresponding feature in sparse format.
Eg of a line:
60 971:1.000000 988:1.000000 1648:1.000000 1717:1.000000 2798:0.364078 3005:0.367953 3049:0.013514
Here, 60 is the patient id and 971:1.000000 988:1.000000 1648:1.000000 1717:1.000000 2798:0.364078 3005:0.367953 3049:0.013514 is the feature for the patient with id 60.

Save the file as "test_features.txt" and save it inside the folder deliverables

input:
output: X_train,Y_train,X_test
'''
def my_features():
	#TODO: complete this
  
  ### load & filter events

  events = pd.read_csv('../data/test/events.csv')
  feature_map = pd.read_csv('../data/test/event_feature_map.csv')

  indx_date = pd.to_datetime(events.groupby('patient_id').timestamp.max()).reset_index()
  indx_date['indx_date'] = indx_date.timestamp
  del indx_date['timestamp']

  joined = events.set_index('patient_id').join(indx_date.set_index('patient_id')).reset_index()
  filt = (pd.to_datetime(joined.timestamp)-pd.to_datetime(joined.indx_date)).apply(lambda n: n.days > -2000 and n.days <= 0)
  filtered_events = events[filt]
  
  ### aggregate events
  
  joined = pd.merge(events,feature_map,how='left',on=['event_id','event_id'])
  joined = joined[joined.value.notna()]
  diag_drug_agg = joined[joined.event_id.apply(lambda s: s[:4] in ['DIAG','DRUG'])].groupby(['patient_id','idx']).value.sum()
  lab_agg = joined[joined.event_id.apply(lambda s: s[:3]=='LAB')].groupby(['patient_id','idx']).value.count()
  agg = diag_drug_agg.append(lab_agg)

  stats = agg.reset_index().groupby('idx').count()
  stats['num_instances'] = stats.value
  del stats['patient_id'], stats['value']
  stats['minval'] = agg.reset_index().groupby('idx').value.min()
  stats['maxval'] = agg.reset_index().groupby('idx').value.max()
  stats['rangeval'] = stats.maxval - stats.minval
  stats['subtrahend'] = stats.minval
  stats['subtrahend'][stats.rangeval==0] = 0
  stats['divisor'] = stats.rangeval
  stats['divisor'][stats.divisor==0] = stats.minval*stats.num_instances
  agg = (agg-stats.subtrahend)/stats.divisor

  aggregated_events = agg.reset_index()

  aggregated_events['feature_value'] = aggregated_events[0]
  aggregated_events['feature_id'] = aggregated_events.idx
  del aggregated_events[0], aggregated_events['idx']
  
  ### create feature file
  
  patient_features = dict(pd.DataFrame({
        'feature_id':aggregated_events.groupby('patient_id')['feature_id'].apply(list),
        'feature_value':aggregated_events.groupby('patient_id')['feature_value'].apply(list)
      }).apply(lambda r: [(r[0][i],r[1][i]) for i in range(len(r[0]))],axis=1).apply(lambda x: sorted(x, key=lambda tup: tup[0])))
 
  deliverable1 = open('../deliverables/test_features.txt', 'wb')

  deliverable1_str = pd.DataFrame({
      'patient_id':pd.Series(patient_features).index,
      'patient_features':pd.Series(patient_features)
    },columns=['patient_id','patient_features']).sort_index().apply(lambda r:str(r[0])+' '+' '.join([str(t[0])+':'+str(t[1]) for t in r[1]])+'\n',axis=1).sum()
  
  deliverable1.write(bytes((deliverable1_str),'UTF-8')); #Use 'UTF-8'
  
  ### load features from file
  
  X_test, discard = utils.get_data_from_svmlight("../deliverables/test_features.txt")
  X_train, Y_train = utils.get_data_from_svmlight("../deliverables/features_svmlight.train")
  
  return X_train, Y_train, X_test


'''
You can use any model you wish.

input: X_train, Y_train, X_test
output: Y_pred
'''
def my_classifier_predictions(X_train,Y_train,X_test):
	#TODO: complete this
  from scipy import sparse
  from sklearn.cluster import KMeans
  
  ### feature selection
  randomforest = RandomForestClassifier(n_estimators=1000,random_state=545510477,criterion='entropy')
  randomforest.fit(X_train, Y_train)

  selected = [i>=0.001 for i in randomforest.feature_importances_]
  X_train = sparse.csr_matrix(X_train.toarray()[:,selected])
  X_test = sparse.csr_matrix(X_test.toarray()[:,selected])
  
  ### unsupervised pre-training
  X_train = X_train.toarray()
  X_test = X_test.toarray()
  X = np.vstack((X_train, X_test))
  kmeans = KMeans(n_clusters=10, random_state=545510477).fit(X)
  train_clusters = kmeans.labels_[:X_train.shape[0]]
  test_clusters = kmeans.labels_[X_train.shape[0]:]
  for cluster_number in range(10):
    bools_train = (train_clusters==cluster_number).astype(float)
    bools_train = np.reshape(bools_train,(bools_train.shape[0],1))
    bools_test = (test_clusters==cluster_number).astype(float)
    bools_test = np.reshape(bools_test,(bools_test.shape[0],1))
    X_train = np.append(X_train, bools_train, 1)
    X_test = np.append(X_test, bools_test, 1)
  X_train = sparse.csr_matrix(X_train)
  X_test = sparse.csr_matrix(X_test)
      
  randomforest = RandomForestClassifier(n_estimators=1000,random_state=545510477,criterion='entropy')
  randomforest.fit(X_train, Y_train)
  Y_pred = randomforest.predict(X_test)
  
  return Y_pred


def main():
  X_train, Y_train, X_test = my_features()
  Y_pred = my_classifier_predictions(X_train,Y_train,X_test)
  utils.generate_submission("../deliverables/test_features.txt",Y_pred)
  #The above function will generate a csv file of (patient_id,predicted label) and will be saved as "my_predictions.csv" in the deliverables folder.

if __name__ == "__main__":
    main()

    