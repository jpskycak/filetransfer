import utils

# PLEASE USE THE GIVEN FUNCTION NAME, DO NOT CHANGE IT

def read_csv(filepath):
    
    '''
    TODO: This function needs to be completed.
    Read the events.csv, mortality_events.csv and event_feature_map.csv files into events, mortality and feature_map.
    
    Return events, mortality and feature_map
    '''

    #Columns in events.csv - patient_id,event_id,event_description,timestamp,value
    events = pd.read_csv(filepath + 'events.csv')
    
    #Columns in mortality_event.csv - patient_id,timestamp,label
    mortality = pd.read_csv(filepath + 'mortality_events.csv')

    #Columns in event_feature_map.csv - idx,event_id
    feature_map = pd.read_csv(filepath + 'event_feature_map.csv')

    return events, mortality, feature_map


def calculate_index_date(events, mortality, deliverables_path):
    
    '''
    TODO: This function needs to be completed.

    Refer to instructions in Q3 a

    Suggested steps:
    1. Create list of patients alive ( mortality_events.csv only contains information about patients deceased)
    2. Split events into two groups based on whether the patient is alive or deceased
    3. Calculate index date for each patient
    
    IMPORTANT:
    Save indx_date to a csv file in the deliverables folder named as etl_index_dates.csv. 
    Use the global variable deliverables_path while specifying the filepath. 
    Each row is of the form patient_id, indx_date.
    The csv file should have a header 
    For example if you are using Pandas, you could write: 
        indx_date.to_csv(deliverables_path + 'etl_index_dates.csv', columns=['patient_id', 'indx_date'], index=False)

    Return indx_date
    '''
    events, mortality, feature_map = read_csv('../data/train/')
    joined = events.set_index('patient_id').join(mortality.set_index('patient_id'),rsuffix='_mortality').reset_index()
    joined.label = joined.label.fillna(value=0)
    dead_index_dates = pd.to_datetime(mortality.set_index('patient_id').timestamp)-pd.Timedelta('30 days')
    alive_index_dates = pd.to_datetime(joined[joined.label==0].groupby('patient_id').timestamp.max())

    indx_date = dead_index_dates.append(alive_index_dates).reset_index()
    indx_date['indx_date'] = indx_date.timestamp
    del indx_date['timestamp']

    indx_date.to_csv(deliverables_path + 'etl_index_dates.csv', columns=['patient_id', 'indx_date'], index=False)
    
    return indx_date


def filter_events(events, indx_date, deliverables_path):
    
    '''
    TODO: This function needs to be completed.

    Refer to instructions in Q3 b

    Suggested steps:
    1. Join indx_date with events on patient_id
    2. Filter events occuring in the observation window(IndexDate-2000 to IndexDate)
    
    
    IMPORTANT:
    Save filtered_events to a csv file in the deliverables folder named as etl_filtered_events.csv. 
    Use the global variable deliverables_path while specifying the filepath. 
    Each row is of the form patient_id, event_id, value.
    The csv file should have a header 
    For example if you are using Pandas, you could write: 
        filtered_events.to_csv(deliverables_path + 'etl_filtered_events.csv', columns=['patient_id', 'event_id', 'value'], index=False)

    Return filtered_events
    '''
    
    indx_date = pd.read_csv(deliverables_path + 'etl_index_dates.csv')
    joined = events.set_index('patient_id').join(indx_date.set_index('patient_id')).reset_index()
    filt = (pd.to_datetime(joined.timestamp)-pd.to_datetime(joined.indx_date)).apply(lambda n: n.days > -2000 and n.days <= 0)
    
    filtered_events = events[filt]
    filtered_events.to_csv(deliverables_path + 'etl_filtered_events.csv', columns=['patient_id', 'event_id', 'value'], index=False)
    return filtered_events


def aggregate_events(filtered_events_df, mortality_df,feature_map_df, deliverables_path):
    
    '''
    TODO: This function needs to be completed.

    Refer to instructions in Q3 c

    Suggested steps:
    1. Replace event_id's with index available in event_feature_map.csv
    2. Remove events with n/a values
    3. Aggregate events using sum and count to calculate feature value
    4. Normalize the values obtained above using min-max normalization(the min value will be 0 in all scenarios)
    
    
    IMPORTANT:
    Save aggregated_events to a csv file in the deliverables folder named as etl_aggregated_events.csv. 
    Use the global variable deliverables_path while specifying the filepath. 
    Each row is of the form patient_id, event_id, value.
    The csv file should have a header .
    For example if you are using Pandas, you could write: 
        aggregated_events.to_csv(deliverables_path + 'etl_aggregated_events.csv', columns=['patient_id', 'feature_id', 'feature_value'], index=False)

    Return filtered_events
    '''
    
    events, mortality, feature_map = read_csv('../data/train/')
    
    joined = pd.merge(events,feature_map,how='left',on=['event_id','event_id'])
    joined = joined[joined.value.notna()]
    diag_drug_agg = joined[joined.event_id.apply(lambda s: s[:4] in ['DIAG','DRUG'])].groupby(['patient_id','idx']).value.sum()
    lab_agg = joined[joined.event_id.apply(lambda s: s[:3]=='LAB')].groupby(['patient_id','idx']).value.count()
    agg = diag_drug_agg.append(lab_agg)
    
    stats = agg.reset_index().groupby('idx').count()
    stats['num_instances'] = stats.value
    del stats['patient_id'], stats['value']
    stats['minval'] = agg.reset_index().groupby('idx').value.min()
    stats['maxval'] = agg.reset_index().groupby('idx').value.max()
    stats['rangeval'] = stats.maxval - stats.minval
    stats['subtrahend'] = stats.minval
    stats['subtrahend'][stats.rangeval==0] = 0
    stats['divisor'] = stats.rangeval
    stats['divisor'][stats.divisor==0] = stats.minval*stats.num_instances
    agg = (agg-stats.subtrahend)/stats.divisor
    
    aggregated_events = agg.reset_index()
    
    aggregated_events['feature_value'] = aggregated_events[0]
    aggregated_events['feature_id'] = aggregated_events.idx
    del aggregated_events[0], aggregated_events['idx']
    aggregated_events.to_csv(deliverables_path + 'etl_aggregated_events.csv', columns=['patient_id', 'feature_id', 'feature_value'], index=False)
    return aggregated_events

def create_features(events, mortality, feature_map):
    
    deliverables_path = '../deliverables/' #'../deliverables/'

    #Calculate index date
    indx_date = calculate_index_date(events, mortality, deliverables_path)

    #Filter events in the observation window
    filtered_events = filter_events(events, indx_date,  deliverables_path)
    
    #Aggregate the event values for each patient 
    aggregated_events = aggregate_events(filtered_events, mortality, feature_map, deliverables_path)

    '''
    TODO: Complete the code below by creating two dictionaries - 
    1. patient_features :  Key - patient_id and value is array of tuples(feature_id, feature_value)
    2. mortality : Key - patient_id and value is mortality label
    '''
    patient_features = dict(pd.DataFrame({
        'feature_id':aggregated_events.groupby('patient_id')['feature_id'].apply(list),
        'feature_value':aggregated_events.groupby('patient_id')['feature_value'].apply(list)
      }).apply(lambda r: [(r[0][i],r[1][i]) for i in range(len(r[0]))],axis=1).apply(lambda x: sorted(x, key=lambda tup: tup[0])))
    
    joined = pd.merge(events, mortality, how='left', on=['patient_id','patient_id'], suffixes=['','_mortality'])
    joined.label = joined.label.fillna(value=0)
    mortality = dict(joined.set_index('patient_id').label.reset_index().groupby('patient_id').min().label.astype(int))

    return patient_features, mortality

def save_svmlight(patient_features, mortality, op_file, op_deliverable):
    
    '''
    TODO: This function needs to be completed

    Refer to instructions in Q3 d

    Create two files:
    1. op_file - which saves the features in svmlight format. (See instructions in Q3d for detailed explanation)
    2. op_deliverable - which saves the features in following format:
       patient_id1 label feature_id:feature_value feature_id:feature_value feature_id:feature_value ...
       patient_id2 label feature_id:feature_value feature_id:feature_value feature_id:feature_value ...  
    
    Note: Please make sure the features are ordered in ascending order, and patients are stored in ascending order as well.     
    '''
    deliverable1 = open(op_file, 'wb')
    deliverable2 = open(op_deliverable, 'wb')
    
    deliverable1_str = pd.DataFrame({
        'patient_features':pd.Series(patient_features),
        'mortality':pd.Series(mortality)
      }).sort_index().apply(lambda r:str(r[0])+' '+' '.join([str(t[0])+':'+str(t[1]) for t in r[1]])+'\n',axis=1).sum()
    deliverable2_str = pd.DataFrame({
        'patient_features':pd.Series(patient_features),
        'mortality':pd.Series(mortality)
      }).sort_index().reset_index().apply(lambda r:str(r[0])+' '+str(r[1])+' '+' '.join([str(t[0])+':'+str(t[1]) for t in r[2]])+'\n',axis=1).sum()
    
    deliverable1.write(bytes((deliverable1_str),'UTF-8')); #Use 'UTF-8'
    deliverable2.write(bytes((deliverable2_str),'UTF-8'));

def main():
    train_path = '../data/train/'
    events, mortality, feature_map = read_csv(train_path)
    patient_features, mortality = create_features(events, mortality, feature_map)
    save_svmlight(patient_features, mortality, '../deliverables/features_svmlight.train', '../deliverables/features.train')

if __name__ == "__main__":
    main()